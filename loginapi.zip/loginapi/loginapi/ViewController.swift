//
//  ViewController.swift
//  loginapi
//
//  Created by Mobicip on 12/05/26.
//

import UIKit
import CryptoKit

class ViewController : UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let (finalInnerJsonString,checksum) = generateChecksum(clientKey:"eQmqIhqfIeNs0OX6avY5YpauB" )
        send(finalInnerJsonString: finalInnerJsonString, checksum: checksum)
    }
    
    func manualJSON(from elements: [(String, Any)]) -> String {
        let pairs = elements.map { (key, value) in
            let formattedValue: String
            
            if let subArray = value as? [(String, Any)] {
                formattedValue = manualJSON(from: subArray)
            } else if let stringValue = value as? String {
                let escapedValue = stringValue.replacingOccurrences(of: "/", with: "\\/")
                formattedValue = "\"\(escapedValue)\""
            } else {
                formattedValue = "\(value)"
            }
            
            return "\"\(key)\":\(formattedValue)"
        }
        return "{" + pairs.joined(separator: ",") + "}"
    }
    
    func generateChecksum(clientKey: String) ->  (String,String){
        
        let apiDetails: [(String, Any)] = [
            ("version","2.3"),
            ("app_version","7.0")
            
        ]
        
        let clientDetails : [(String, Any)] = [
            ("version","2.2"),
            ("identity","21V21B337GMX2"),
            ("session_hash","de951cc9-0a2e-41fd-918d-b2f55c09d780")
        ]
        
        let userDetails: [(String, Any)] = [
            ("timezone","Asia/Kolkata"),
            ("email","intern+ios@mobicip.com"),
            ("password","12345")
        ]
        
        let sessionDetails: [(String, Any)] = [
            ("token", "NO-TOKEN")
        ]
        
        let body: [(String, Any)] = [
            ("api", apiDetails),
            ("Client", clientDetails),
            ("User", userDetails),
            ("Session", sessionDetails)
        ]
        
        let requestString = manualJSON( from: body)
        print(requestString)
        print()
        
        let token = "NO-TOKEN"
        let clientKey = "eQmqIhqfIeNs0OX6avY5YpauB"
        let hmacInput = token + requestString + clientKey
        
        let hmacKey = SymmetricKey(data: Data(token.utf8))
        let signature = HMAC<SHA256>.authenticationCode(for: Data(hmacInput.utf8), using: hmacKey)
        let checksum = signature.map { String(format: "%02x", $0) }.joined()
        print(checksum)
        print()
        
        let finalInnerJsonString = manualJSON(from: body)

         return (finalInnerJsonString, checksum)
    }
    
    func send(finalInnerJsonString: String, checksum: String) {
        
        let escapedRequest = finalInnerJsonString
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "/", with: "\\/")
            .replacingOccurrences(of: "\"", with: "\\\"")
        
        let finalWrapperString =
        """
        {
        "mwsRequest": {
        "String": {
        "Request": "\(escapedRequest)"
        },
        "Checksum": "\(checksum)"
        }
        }
        """
        
       let finalBody = finalWrapperString
            .replacingOccurrences(of: "\n", with: " ")
        
        print("FINAL BODY:")
        print(finalBody)
        print()
        
        guard let url = URL(string: "https://webd.prgr.in/api/v2/login") else {
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        request.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = Data(finalBody.utf8)
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                return
            }
            
            print("Status Code: \(httpResponse.statusCode)")
            
            if let data = data,
               let responseString = String(data: data, encoding: .utf8) {
                print("Server Response:")
                print(responseString)
            }
            
        }.resume()
    }
}



